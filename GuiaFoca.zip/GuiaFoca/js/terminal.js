
document.addEventListener('DOMContentLoaded', function () {

  document.getElementsByTagName('form')[0].onsubmit = function (evt) {
    evt.preventDefault(); // Preventing the form from submitting
    checkWord(); // Do your magic and check the entered word/sentence
    gravar();
    window.scrollTo(0, 150);
  }

  document.getElementById('terminalTextInput').focus();

  var textInputValue = document.getElementById('terminalTextInput').value.trim();

  var textResultsValue = document.getElementById('terminalReslutsCont').innerHTML;

  var clearInput = function () {
    document.getElementById('terminalTextInput').value = "";
  }

  var clearAll = function () {
    document.getElementById('terminalReslutsCont').innerHTML = "";
  }

  // Scrtoll to the bottom of the results div
  var scrollToBottomOfResults = function () {
    var terminalResultsDiv = document.getElementById('terminalReslutsCont');
    terminalResultsDiv.scrollTop = terminalResultsDiv.scrollHeight;
  }

  // Scroll to the bottom of the results
  scrollToBottomOfResults();

  // Add text to the results div
  var addTextToResults = function (textToAdd) {
    document.getElementById('terminalReslutsCont').innerHTML += "<p>" + textToAdd + "</p>";
    scrollToBottomOfResults();
  }

  addTextToResults('Bem-vindo, aprendiz! <br/> Antes de tudo, vamos criar seu usuário, digite: <br/> adduser -disabled-login <i>seunome</i>');
  addTextToResults('Para listar os comandos, digite <i>list</i>');

  terminalTextInput.addEventListener('keydown', retornaStr);

  var count = 0;

  function retornaStr(e) {
    if (`${e.code}` == 'ArrowUp') {
      count++;
      var text = arrayInput[arrayInput.length - count];
      document.getElementById('terminalTextInput').value = text;
    } else
      if (`${e.code}` == 'Enter') { count = 0; }
  }



  //help de alguns comandos
  var postHelpList = function () {
    var list = [
      "[uname]: retorna as configurações do sistema; [uname -i] nos informa a plataforma de hardware; [uname -o] retorna o sistema operacional.",
      "[help]: manual de instruções para a ferramenta que você está utilizando no terminal – [ls -–help].",
      "[logout]: sai do sistema sem que as informações fiquem salvas.  ",
      "[reboot]: reinicia o computador.",
      "[poweroff]: desliga a máquina abruptamente.        ",
      "[halt]: interrompe todas as funções da CPU.          ",
      "[apt]: O apt é uma ferramenta-chave do Linux, mais precisamente distribuições baseadas em Debian, cuja função é auxiliar na instalação, atualização, remoção de software, inclusão ou exclusão de repositórios.",
      "[date]: retorna a data.    ",
      "[time]: retorna a hora.  ",
      "[clear]: limpa o terminal. ",
      "[rmdir]: exclui repositórios – [rmdir diretorioteste]. ",
      "[mkdir]: cria repositórios – [mkdir diretorioteste]. ",
      "[cd]: utilizamos para explorar diretórios por meio do terminal é o Change Directory (mudar de diretório) – [cd diretorioteste/]. ",
      "[su]: troca para o usuário especificado em 'user' – [su user]. ",
      "[adduser -disabled-login]: cria usuários sem necessidade de colocar senha – [adduser -disabled-login usuarioteste].  ",
      "[touch]: cria arquivos sem precisar inserir conteúdos – [touch arq.txt].",
      "[ls]: lista os arquivos e diretórios do sistema. "
    ].join('<br>');

    addTextToResults(list);
  }

  var postHelpListLS = function () {
    var list = [
      "Usage: ls [OPTION]... [FILE]...",
      "List information about the FILEs (the current directory by default).",
      "Sort entries alphabetically if none of -cftuvSUX nor --sort is specified.",
      "Mandatory arguments to long options are mandatory for short options too.",
      "  -a, --all                  do not ignore entries starting with .",
      "  -A, --almost-all           do not list implied . and ..",
      "      --author               with -l, print the author of each file",
      "  -b, --escape               print C-style escapes for nongraphic characters",
      "      --block-size=SIZE      with -l, scale sizes by SIZE when printing them;",
      "                               e.g., '--block-size=M'; see SIZE format below",
      "  -B, --ignore-backups       do not list implied entries ending with ~",
      "  -c                         with -lt: sort by, and show, ctime (time of last",
      "                               modification of file status information);",
      "                             with -l: show ctime and sort by name;",
      "                               otherwise: sort by ctime, newest first",
      "  -C                         list entries by columns",
      "      --color[=WHEN]         colorize the output; WHEN can be 'always' (default",
      "                               if omitted), 'auto', or 'never'; more info below",
      "  -d, --directory            list directories themselves, not their contents",
      "  -D, --dired                generate output designed for Emacs' dired mode",
      "  -f                         do not sort, enable -aU, disable -ls --color",
      "  -F, --classify             append indicator (one of */=>@|) to entries",
      "      --file-type            likewise, except do not append '*'",
      "      --format=WORD          across -x, commas -m, horizontal -x, long -l,",
      "                               single-column -1, verbose -l, vertical -C",
      "      --full-time            like -l --time-style=full-iso",
      "  -g                         like -l, but do not list owner",
      "      --group-directories-first",
      "                             group directories before files;",
      "                               can be augmented with a --sort option, but any",
      "                               use of --sort=none (-U) disables grouping",
      "  -G, --no-group             in a long listing, don't print group names",
      "  -h, --human-readable       with -l and -s, print sizes like 1K 234M 2G etc.",
      "      --si                   likewise, but use powers of 1000 not 1024",
      "  -H, --dereference-command-line",
      "                             follow symbolic links listed on the command line",
      "     --dereference-command-line-symlink-to-dir",
      "                             follow each command line symbolic link",
      "                               that points to a directory",
      "      --hide=PATTERN         do not list implied entries matching shell PATTERN",
      "                               (overridden by -a or -A)",
      "      --hyperlink[=WHEN]     hyperlink file names; WHEN can be 'always'",
      "                               (default if omitted), 'auto', or 'never'",
      "      --indicator-style=WORD  append indicator with style WORD to entry names:",
      "                              none (default), slash (-p),",
      "                               file-type (--file-type), classify (-F)",
      "  -i, --inode                print the index number of each file",
      "  -I, --ignore=PATTERN       do not list implied entries matching shell PATTERN",
      "  -k, --kibibytes            default to 1024-byte blocks for disk usage;",
      "                               used only with -s and per directory totals",
      "  -l                         use a long listing format",
      "  -L, --dereference          when showing file information for a symbolic",
      "                               link, show information for the file the link",
      "                               references rather than for the link itself",
      "  -m                         fill width with a comma separated list of entries",
      "  -n, --numeric-uid-gid      like -l, but list numeric user and group IDs",
      "  -N, --literal              print entry names without quoting",
      "  -o                         like -l, but do not list group information",
      "  -p, --indicator-style=slash",
      "                             append / indicator to directories",
      "  -q, --hide-control-chars   print ? instead of nongraphic characters",
      "      --show-control-chars   show nongraphic characters as-is (the default,",
      "                               unless program is 'ls' and output is a terminal)",
      "  -Q, --quote-name           enclose entry names in double quotes",
      "      --quoting-style=WORD   use quoting style WORD for entry names:",
      "                               literal, locale, shell, shell-always,",
      "                               shell-escape, shell-escape-always, c, escape",
      "                               (overrides QUOTING_STYLE environment variable)",
      "  -r, --reverse              reverse order while sorting",
      "  -R, --recursive            list subdirectories recursively",
      "  -s, --size                 print the allocated size of each file, in blocks",
      "  -S                         sort by file size, largest first",
      "      --sort=WORD            sort by WORD instead of name: none (-U), size (-S),",
      "                               time (-t), version (-v), extension (-X)",
      "      --time=WORD            with -l, show time as WORD instead of default",
      "                               modification time: atime or access or use (-u);",
      "                               ctime or status (-c); also use specified time",
      "                               as sort key if --sort=time (newest first)",
      "      --time-style=TIME_STYLE  time/date format with -l; see TIME_STYLE below",
      "  -t                         sort by modification time, newest first",
      "  -T, --tabsize=COLS         assume tab stops at each COLS instead of 8",
      "  -u                         with -lt: sort by, and show, access time;",
      "                               with -l: show access time and sort by name;",
      "                               otherwise: sort by access time, newest first",
      "  -U                         do not sort; list entries in directory order",
      "  -v                         natural sort of (version) numbers within text",
      "  -w, --width=COLS           set output width to COLS.  0 means no limit",
      "  -x                         list entries by lines instead of by columns",
      "  -X                         sort alphabetically by entry extension",
      "  -Z, --context              print any security context of each file",
      "  -1                         list one file per line.  Avoid '\n' with -q or -b",
      "  --help     display this help and exit",
      "  --version  output version information and exit"
    ].join('<br>');

    addTextToResults(list);
  }

  var getTimeAndDate = function (postTimeDay) {
    var timeAndDate = new Date();
    var timeHours = timeAndDate.getHours();
    var timeMinutes = timeAndDate.getMinutes();
    var dateDay = timeAndDate.getDate();
    console.log(dateDay);
    var dateMonth = timeAndDate.getMonth() + 1; // Because JS starts counting months from 0
    var dateYear = timeAndDate.getFullYear(); // Otherwise we'll get the count like 98,99,100,101...etc.

    if (timeHours < 10) { // if 1 number display 0 before it.
      timeHours = "0" + timeHours;
    }

    if (timeMinutes < 10) { // if 1 number display 0 before it.
      timeMinutes = "0" + timeMinutes;
    }

    var currentTime = timeHours + ":" + timeMinutes;
    var currentDate = dateDay + "/" + dateMonth + "/" + dateYear;

    if (postTimeDay == "time") {
      addTextToResults(currentTime);
    }
    if (postTimeDay == "date") {
      addTextToResults(currentDate);
    }
  }

  var textReplies = function () {
    switch (textInputValueLowerCase) {
      // replies
      case "uname":
        clearInput();
        addTextToResults("Digite <i>uname -i</i> para ver a plataforma hardware ou <i>uname -o</i> para ver o sistema operacional.");
        break;

      case "uname -i":
        clearInput();
        addTextToResults("x86_64");
        break;

      case "uname -o":
        clearInput();
        addTextToResults("Debian");
        break;

      case "help":
        clearInput();
        addTextToResults("Digite <i>[comando] --help</i> para ver os recursos existentes no comando. Tente <b>ls --help</b>");
        break;

      case "logout":
        clearInput();
        alert('Você saiu do sistema sem deixar as credenciais ativas.');
        window.location.reload();
        break;

      case "reboot":
      case "poweroff":
      case "halt":
        clearInput();
        addTextToResults("Os sistemas baseados em Linux nos colocam à disposição os comandos reboot, halt e poweroff para reiniciar, interromper e desligar o computador, respectivamente.");
        break;

      case "apt":
        clearInput();
        addTextToResults("O comando apt é uma ferramenta-chave do Linux, mais precisamente distribuições baseadas em Debian, cuja função é auxiliar na instalação, atualização, remoção de software, inclusão / exclusão de repositórios etc.");
        break;

      case "time":
        clearInput();
        getTimeAndDate("time");
        break;

      case "date":
        clearInput();
        getTimeAndDate("date");
        break;

      case "help":
      case "?":
        clearInput();
        postHelpList();
        break;

      default:
        clearInput();
        addTextToResults("<p><i>The command " + "<b>" + textInputValue + "</b>" + " was not found. Type <b>list</b> to see all commands.</i></p>");
        break;
    }
  }

  var arrayInput = [];
  var arrayArq = [];
  var arrayRep = [];
  var user = 'user';
  var usr = user;
  var directory = '~';

  var checkWord = function () {
    textInputValue = document.getElementById('terminalTextInput').value.trim(); //get the text from the text input to a variable
    console.log(textInputValue);
    textInputValueLowerCase = textInputValue.toLowerCase(); //get the lower case of the string

    if (textInputValue != "") {

      arrayInput[arrayInput.length] = textInputValue;

      addTextToResults("<p class='userEnteredText'>" + user + "@debian:" + directory + "# " + textInputValue + "</p>");

      if (textInputValueLowerCase.substr(0, 5) == 'clear') {
        clearAll();
        clearInput();
      } else {
        if (textInputValueLowerCase.substr(0, 24) == 'adduser -disabled-login ') {
          clearInput();
          usr = textInputValue.substr(24);
          addTextToResults('Eba! Agora que criou seu usuário, vamos acessá-lo, digite:<br/> su ' + textInputValue.substr(24));
        } else {
          if (textInputValueLowerCase.substr(0, 2) == 'su') {
            clearInput();
            user = usr;
            addTextToResults('Que ótimo! Agora que você já criou seu usuário, podemos começar!');
            addTextToResults('<br/> Vamos criar um diretório, digite:<br/> mkdir <i>nomediretorio</i>');
          } else {
            if (textInputValueLowerCase.substr(0, 4) == 'exit') {
              clearInput();
              addTextToResults('Esse é o comando para sair do usuário, você voltou ao user inicial.');
              addTextToResults('exit');
              user = 'user';
            } else {
              if (textInputValueLowerCase.substr(0, 5) == 'mkdir') {
                clearInput();
                directory = textInputValueLowerCase.substr(5);
                arrayRep[arrayRep.length] = directory;
              } else {
                if (textInputValueLowerCase.substr(0, 2) == 'cd') {
                  clearInput();
                  diretorioin = textInputValue.substr(2);
                  for (i = 0; i <= arrayRep.length; i++) {
                    if (diretorioin == arrayRep[i]) {
                      directory = diretorioin;
                    }
                  }
                  if (directory != diretorioin) {
                    addTextToResults("O sistema não pode encontrar o caminho especificado.</p>")
                  } else {
                    addTextToResults('Agora que você já está em um novo diretório, vamos criar um arquivo? <br/> Digite <i>touch arquivo </i> para criar um arquivo sem conteúdo.');
                  }
                } else {
                  if (textInputValueLowerCase.substr(0, 5) == 'touch') {
                    clearInput();
                    arrayArq[arrayArq.length] = textInputValueLowerCase.substr(5);
                    addTextToResults("Seu arquivo foi criado! Digite <i>ls</i> para ver seus arquivos e diretórios!");
                  } else {
                    if (textInputValueLowerCase.substr(0, 2) == 'ls' && textInputValueLowerCase.substr(0, 4) != 'ls -') {
                      clearInput();
                      addTextToResults("Diretórios:");
                      for (i = 0; i < arrayRep.length; i++) {
                        addTextToResults(arrayRep[i]);
                      }
                      addTextToResults(" ");
                      addTextToResults("Arquivos:");
                      for (i = 0; i < arrayArq.length; i++) {
                        addTextToResults(arrayArq[i]);
                      }
                    } else {
                      if (textInputValueLowerCase.substr(0, 5) == 'rmdir') {
                        clearInput();
                        diretorioout = textInputValue.substr(5);
                        for (i = 0; i <= arrayRep.length; i++) {
                          if (diretorioout == arrayRep[i]) {
                            arrayRep.splice(i);
                          }
                        }
                        if (directory != diretorioout) {
                          addTextToResults("O sistema não pode encontrar o caminho especificado.</p>")
                        } else {
                          addTextToResults('Você removeu o diretório <i>[' + diretorioout + ']</i>.');
                        }
                      } else {
                        if (textInputValueLowerCase.substr(0,4) == 'list' || textInputValueLowerCase.substr(0,1) == '?') {
                          clearInput();
                          postHelpList();
                        } else {
                          if (textInputValueLowerCase.substr(0, 9) == 'ls --help') {
                            clearInput();
                            postHelpListLS();
                          } else {
                            textReplies();
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  };

});